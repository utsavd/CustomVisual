module powerbi.extensibility.visual {

    interface BarChartViewModel {
        dataPoints: BarChartDataPoints[];
        dataMax: number;
        dataMin: number;
    };
    interface BarChartDataPoints {
        mx: number;
        mn: number;
        cen: number;
        category: string;
    };



    export class Visual implements IVisual {

        private svg: d3.Selection<SVGElement>;
        private host: IVisualHost;
        private barContainer: d3.Selection<SVGElement>;
        private bars: d3.Selection<SVGElement>;
        private xAxis: d3.Selection<SVGAElement>;
        private yAxis: d3.Selection<SVGAElement>;

        constructor(options: VisualConstructorOptions) {
            this.host = options.host;
            let svg = this.svg = d3.select(options.element)
                .append('svg')
                .classed('barChart', true)

            this.barContainer = svg.append('g')
                .classed('barContainer', true);

            this.xAxis = svg.append('g')
                .classed('Axis', true);

            this.yAxis = svg.append('g')
                .classed('Axis', true);

          

        }

        public update(options: VisualUpdateOptions) {
            /*let testData: BarChartDataPoints[] = [
                {
                    value: 10,
                    category: 'a'
                },
                {
                    value: 20,
                    category: 'b'
                },
                {
                    value: 1,
                    category: 'c'
                },
                {
                    value: 100,
                    category: 'd'
                },
                {
                    value: 500,
                    category: 'e'
                }];*/


            let margin = { top: 50, bottom: 25, left: 50, right: 0 };

            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'https://api.myjson.com/bins/i2fm9', false);
            var chartData;
            xhr.onload = function () {
                if (xhr.status === 200) {
                    chartData = JSON.parse(xhr.responseText);
                }
            };
            xhr.send();


            let i: number;
            let testData: BarChartDataPoints[] = new Array();
            
            //debugger;
            for (i = 0; i < chartData.length; i++) {
                let nbar = {
                    mx: chartData[i]["High"],
                    mn: chartData[i]["Low"],
                    cen: chartData[i]["NPS"],
                    category: chartData[i]["MonthName"]
                };
               // console.log(nbar);
                testData.push(nbar);


            }
            //console.log(testData);
            //debugger;

            //{
            //    mx: chartData[0]["High"],
            //        mn: chartData[0]["Low"],
            //            cen: chartData[0]["NPS"],
            //                category: chartData[0]["MonthName"]
            //},

            
            //let testData: BarChartDataPoints[] = [
            //    {
            //        mx: chartData[1]["High"],
            //        mn: chartData[1]["Low"],
            //        cen: chartData[1]["NPS"],
            //        category: chartData[1]["MonthName"]
            //    }];



            let width = options.viewport.width;
            let height = options.viewport.height;



            /*let viewModel: BarChartViewModel = {
                dataPoints: testData,
                dataMax: d3.max(testData.map((dataPoint) => dataPoint.value))
            };*/

            let viewModel: BarChartViewModel = {
                dataPoints: testData,
                dataMax: d3.max(testData, x => x.mx),
                dataMin: d3.min(testData, x => x.mn)
            };

            this.svg.attr({
                width: width,
                height: height
            });

            let yScale = d3.scale.linear()
                .domain([viewModel.dataMin, viewModel.dataMax+1])
                .range([height - (margin.bottom), 0]);

            let xScale = d3.scale.ordinal()
                .domain(viewModel.dataPoints.map(d => d.category))
                .rangeRoundBands([0, width], 0.0);

            let xAxis = d3.svg.axis()
                .scale(xScale)
                .orient('bottom');

            let yAxis = d3.svg.axis()
                .scale(yScale)
                .orient('left');

            this.xAxis.attr('transform', 'translate(0, ' + (height - margin.bottom) + ')')
                .call(xAxis);

            this.yAxis.attr("transform", "translate(" + (margin.left) + ",0)")
                .call(yAxis);

            this.svg.append("text")
                .attr("x", width / 2)
                .attr("y", height - 1)
                .style("text-anchor", "middle")
                .text("Date");

            this.svg.append("text")
                .attr("transform", "translate(" + (margin.bottom / 2) + "," + (height / 2) + ")rotate(-90)")
                .style("text-anchor", "middle")
                .text("NPS Score");

            //this.svg.selectAll('.bar').data(viewModel.dataPoints).remove();

            let bars = this.barContainer.selectAll('.bar').classed('bars', true).data(viewModel.dataPoints);
                
            bars.enter()
                .append('line')
                .attr({
                    "x1": d => xScale(d.category) + width / (2 * testData.length),
                    "y1": d => yScale(d.mn),
                    "x2": d => xScale(d.category) + width / (2 * testData.length),
                    "y2": d => yScale(d.mx),
                    "stroke-width": 1,
                    "stroke": "black",
                    "shape-rendering": "crispEdges"
                });

            bars.enter().append('line')
                .attr({
                    "x1": d => xScale(d.category) - 15 + width / (2 * testData.length),
                    "y1": d => yScale(d.mx),
                    "x2": d => xScale(d.category) + 15 + width / (2 * testData.length),
                    "y2": d => yScale(d.mx),
                    "stroke-width": 1,
                    "stroke": "black",
                    "shape-rendering": "crispEdges"
                });

            bars.enter().append('line')
                .attr({
                    "x1": d => xScale(d.category) - 15 + width / (2 * testData.length),
                    "y1": d => yScale(d.mn),
                    "x2": d => xScale(d.category) + 15 + width / (2 * testData.length),
                    "y2": d => yScale(d.mn),
                    "stroke-width": 1,
                    "stroke": "black",
                    "shape-rendering": "crispEdges"
                });

            bars.enter().append('circle')
                .attr({
                    "cx": d => xScale(d.category) + width / (2 * testData.length),
                    "cy": d => yScale(d.cen),
                    "r": 2,
                    "stroke-width": 1,
                    "stroke": "black"
                });

            bars.exit()
                .remove();
        }

        /*private getViewModel(options: VisualUpdateOptions): BarChartViewModel {

            let dv = options.dataViews;

            let viewModel: BarChartViewModel = {
                dataPoints: [],
                dataMax: 0
            };

            if (!dv
                || !dv[0]
                || !dv[0].categorical
                || !dv[0].categorical.categories
                || !dv[0].categorical.categories[0].source
                || !dv[0].categorical.values)
                return viewModel;

            let view = dv[0].categorical;
            let categories = view.categories[0];
            let values = view.values[0];

            for (let i = 0, len = Math.max(categories.values.length, values.values.length); i < len; i++) {
                viewModel.dataPoints.push({
                    category: <string>categories.values[i],
                    value: <number>values.values[i]
                });
            }

            viewModel.dataMax = d3.max(viewModel.dataPoints, d => d.value);
            return viewModel;
        }*/

        public destroy(): void {

        }
    }
}
